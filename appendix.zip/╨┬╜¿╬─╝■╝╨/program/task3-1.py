import numpy as np
import pandas as pd

side = pd.read_excel(r'D:\大作业\aaa.xlsx')#aaa表格内整理了每台售货机内每种商品的销量
side = side.loc[side['大类']=='饮料',:]

aaa= pd.read_csv(r'D:\大作业\合并数据A.csv',encoding='utf_8_sig')
aaa=aaa.loc[aaa['大类']=='饮料',:]
aaa=aaa['商品'].value_counts()
print(aaa[0:(int(len(aaa)*0.2))])#打印剔除0销量后的销量前20%商品
print(aaa[0:(int(len(aaa)*0.4))])#打印剔除0销量后的销量前40%商品
side_A=side
side_A['标签']='a'

#根据先前打印的商品的最低销量，判断是否畅销，贴上标签
side_A.loc[(side_A['A售货机销量']>=90),'标签']='畅销'
side_A.loc[(side_A['A售货机销量']<90),'标签']='正常'
side_A.loc[(side_A['A售货机销量']<39),'标签']='滞销'
print(side_A)
del side_A['大类']
del side_A['二级类']
del side_A['A售货机销量']
del side_A['B售货机销量']
del side_A['C售货机销量']
del side_A['D售货机销量']
del side_A['E售货机销量']
print(side_A)
side_A.to_csv(r'D:\大作业\task3-1A.csv',encoding='utf_8_sig')


#对每个售货机重复操作，以E售货机为例，其余售货机的代码不做展示
eee= pd.read_csv(r'D:\大作业\合并数据E.csv',encoding='utf_8_sig')
eee=eee.loc[eee['大类']=='饮料',:]
eee=eee['商品'].value_counts()
print(eee[0:(int(len(eee)*0.2))])#打印剔除0销量后的销量前20%商品
print(eee[0:(int(len(eee)*0.4))])#打印剔除0销量后的销量前40%商品
side_E=side
side_E['标签']='a'

#根据先前打印的商品的最低销量，判断是否畅销，贴上标签
side_E.loc[(side_E['E售货机销量']>=220),'标签']='畅销'
side_E.loc[(side_E['E售货机销量']<220),'标签']='正常'
side_E.loc[(side_E['E售货机销量']<83),'标签']='滞销'
print(side_E)
del side_E['大类']
del side_E['二级类']
del side_E['A售货机销量']
del side_E['B售货机销量']
del side_E['C售货机销量']
del side_E['D售货机销量']
del side_E['E售货机销量']
print(side_E)
side_E.to_csv(r'D:\大作业\task3-1E.csv',encoding='utf_8_sig')

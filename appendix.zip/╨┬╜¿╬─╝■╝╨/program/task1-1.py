import pandas as pd
#读取附件1
aaa = pd.read_csv(r'D:\项目数据\附件1.csv',encoding='gbk')
#把不同地点的售货机数据提取出来
aaaA=aaa.loc[aaa['地点']=='A', :]
aaaB=aaa.loc[aaa['地点']=='B', :]
aaaC=aaa.loc[aaa['地点']=='C', :]
aaaD=aaa.loc[aaa['地点']=='D', :]
aaaE=aaa.loc[aaa['地点']=='E', :]
#分别保存成csv文件
aaaA.to_csv(r'D:\大作业\task1-1A.csv',encoding='utf_8_sig')
aaaB.to_csv(r'D:\大作业\task1-1B.csv',encoding='utf_8_sig')
aaaC.to_csv(r'D:\大作业\task1-1C.csv',encoding='utf_8_sig')
aaaD.to_csv(r'D:\大作业\task1-1D.csv',encoding='utf_8_sig')
aaaE.to_csv(r'D:\大作业\task1-1E.csv',encoding='utf_8_sig')

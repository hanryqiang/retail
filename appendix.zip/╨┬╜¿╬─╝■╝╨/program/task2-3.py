import pandas as pd
import numpy as np
ccc= pd.read_csv(r'D:\大作业\合并数据.csv',encoding='utf_8_sig')
gg=ccc.loc[ccc['大类']=='饮料',:]
jj=ccc.loc[ccc['大类']=='非饮料',:]
profit=np.sum(gg['实际金额'])*0.25+np.sum(jj['实际金额'])*0.2

c1= pd.read_csv(r'D:\大作业\合并数据A.csv',encoding='utf_8_sig')
c2= pd.read_csv(r'D:\大作业\合并数据B.csv',encoding='utf_8_sig')
c3= pd.read_csv(r'D:\大作业\合并数据C.csv',encoding='utf_8_sig')
c4= pd.read_csv(r'D:\大作业\合并数据D.csv',encoding='utf_8_sig')
c5= pd.read_csv(r'D:\大作业\合并数据E.csv',encoding='utf_8_sig')
g1=c1.loc[c1['大类']=='饮料',:]
j1=c1.loc[c1['大类']=='非饮料',:]
profitA=np.sum(g1['实际金额'])*0.25+np.sum(j1['实际金额'])*0.2

g2=c2.loc[c2['大类']=='饮料',:]
j2=c2.loc[c2['大类']=='非饮料',:]
profitB=np.sum(g2['实际金额'])*0.25+np.sum(j2['实际金额'])*0.2

g3=c3.loc[c3['大类']=='饮料',:]
j3=c3.loc[c3['大类']=='非饮料',:]
profitC=np.sum(g3['实际金额'])*0.25+np.sum(j3['实际金额'])*0.2

g4=c4.loc[c4['大类']=='饮料',:]
j4=c4.loc[c4['大类']=='非饮料',:]
profitD=np.sum(g4['实际金额'])*0.25+np.sum(j4['实际金额'])*0.2

g5=c5.loc[c5['大类']=='饮料',:]
j5=c5.loc[c5['大类']=='非饮料',:]
profitE=np.sum(g5['实际金额'])*0.25+np.sum(j5['实际金额'])*0.2


ss=[profitA,profitB,profitC,profitD,profitE]
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False
plt.figure(figsize=(6,6))
label= ['A售货机毛利润','B售货机毛利润','C售货机毛利润','D售货机毛利润','E售货机毛利润']
explode = [0.01, 0.01, 0.01, 0.01, 0.01]
plt.pie(ss, explode=explode, labels=label, autopct='%1.1f%%')
plt.title('售货机毛利润饼图')

plt.show()
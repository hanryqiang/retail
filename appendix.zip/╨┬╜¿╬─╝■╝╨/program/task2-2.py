import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
dA = pd.read_csv(r'D:\大作业\task1-1A.csv',encoding='utf_8_sig')
dB = pd.read_csv(r'D:\大作业\task1-1B.csv',encoding='utf_8_sig')
dC = pd.read_csv(r'D:\大作业\task1-1C.csv',encoding='utf_8_sig')
dD = pd.read_csv(r'D:\大作业\task1-1D.csv',encoding='utf_8_sig')
dE = pd.read_csv(r'D:\大作业\task1-1E.csv',encoding='utf_8_sig')
dA['支付时间'] = pd.to_datetime(dA['支付时间'])
dB['支付时间'] = pd.to_datetime(dB['支付时间'])
dC['支付时间'] = pd.to_datetime(dC['支付时间'])
dD['支付时间'] = pd.to_datetime(dD['支付时间'])
dE['支付时间'] = pd.to_datetime(dE['支付时间'])

def counts(series):
    ss=[]
    for i in range(1,13):
        di=series[series['支付时间'].dt.month==i]
        si=np.sum(di['应付金额'])
        ss.append(si)
    return ss 

def huanbi(series):
    hh=[]
    jj=counts(series)
    for i in range(0,11):
        hi=(jj[i+1]-jj[i])/jj[i]*100
        hh.append(hi)
    return hh
month=['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月']

p1 = plt.figure(figsize=(16,16))
plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False
ax1 = p1.add_subplot(2,3,1)
plt.plot(range(12),counts(dA),range(12),counts(dB),range(12),counts(dC),range(12),counts(dD),range(12),counts(dE))
plt.legend(['A售货机','B售货机','C售货机','D售货机','E售货机'])
plt.xlabel('月份')
plt.ylabel('总交易额')
plt.xticks(range(12),month)
plt.title('A售货机每月总交易额折线图')

ax2 = p1.add_subplot(2,3,2)
plt.bar(range(1,12),huanbi(dA))
plt.xlabel('环比月份')
plt.ylabel('环比增长率(%)')
plt.xticks(range(1,12))
plt.title('A售货机交易额月环比增长率柱状图')

ax3 = p1.add_subplot(2,3,3)
plt.bar(range(1,12),huanbi(dB))
plt.xlabel('环比月份')
plt.ylabel('环比增长率(%)')
plt.xticks(range(1,12))
plt.title('B售货机交易额月环比增长率柱状图')

ax2 = p1.add_subplot(2,3,4)
plt.bar(range(1,12),huanbi(dC))
plt.xlabel('环比月份')
plt.ylabel('环比增长率(%)')
plt.xticks(range(1,12))
plt.title('C售货机交易额月环比增长率柱状图')

ax2 = p1.add_subplot(2,3,5)
plt.bar(range(1,12),huanbi(dD))
plt.xlabel('环比月份')
plt.ylabel('环比增长率(%)')
plt.xticks(range(1,12))
plt.title('D售货机交易额月环比增长率柱状图')

ax2 = p1.add_subplot(2,3,6)
plt.bar(range(1,12),huanbi(dE))
plt.xlabel('环比月份')
plt.ylabel('环比增长率(%)')
plt.xticks(range(1,12))
plt.title('E售货机交易额月环比增长率柱状图')
plt.show()
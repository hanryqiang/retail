import pandas as pd
#读取task1-1A.csv
dddA = pd.read_csv(r'D:\大作业\task1-1A.csv',encoding='utf_8_sig')
#转化数据类型为时间
dddA['支付时间'] = pd.to_datetime(dddA['支付时间'])
#提取五月份的数据
dataA=dddA[(pd.to_datetime('20170531')>=dddA['支付时间']) & (dddA['支付时间']>=pd.to_datetime('20170501'))]
#打印，行数即为订单数量
print(dataA)
import numpy as np 
#计算交易额
allA=np.sum(dataA['实际金额'])
print(allA)

#同样的操作可以获取其他地区的订单量和交易额
dddB = pd.read_csv(r'D:\大作业\task1-1B.csv',encoding='utf_8_sig')
dddB['支付时间'] = pd.to_datetime(dddB['支付时间'])
dataB=dddB[(pd.to_datetime('20170531')>=dddB['支付时间']) & (dddB['支付时间']>=pd.to_datetime('20170501'))]
print(dataB)
allB=np.sum(dataB['实际金额'])
print(allB)
#这里c表里面有个错误时间，要删掉
dddC = pd.read_csv(r'D:\大作业\task1-1C.csv',encoding='utf_8_sig')
dddC['支付时间'] = pd.to_datetime(dddC['支付时间'])
dataC=dddC[(pd.to_datetime('20170531')>=dddC['支付时间']) & (dddC['支付时间']>=pd.to_datetime('20170501'))]
print(dataC)
allC=np.sum(dataC['实际金额'])
print(allC)
dddD = pd.read_csv(r'D:\大作业\task1-1D.csv',encoding='utf_8_sig')
dddD['支付时间'] = pd.to_datetime(dddD['支付时间'])
dataD=dddD[(pd.to_datetime('20170531')>=dddD['支付时间']) & (dddD['支付时间']>=pd.to_datetime('20170501'))]
print(dataD)
allD=np.sum(dataD['实际金额'])
print(allD)
dddE = pd.read_csv(r'D:\大作业\task1-1E.csv',encoding='utf_8_sig')
dddE['支付时间'] = pd.to_datetime(dddE['支付时间'])
dataE=dddE[(pd.to_datetime('20170531')>=dddE['支付时间']) & (dddE['支付时间']>=pd.to_datetime('20170501'))]
print(dataE)
allE=np.sum(dataE['实际金额'])
print(allE)

#计算总的交易额和订单量
All=allA+allB+allC+allD+allE
print('总的交易额为:',All)
counts=dataA.shape[0]+dataB.shape[0]+dataC.shape[0]+dataD.shape[0]+dataE.shape[0]
print('总的订单量为:',counts)
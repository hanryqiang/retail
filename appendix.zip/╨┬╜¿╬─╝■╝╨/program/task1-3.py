#以A为例子
import pandas as pd
import numpy as np
#读取task1-1A.csv
dddA = pd.read_csv(r'D:\大作业\task1-1A.csv',encoding='utf_8_sig')
dddA['支付时间'] = pd.to_datetime(dddA['支付时间'])
order1=[1,2,3,4,5,6,7,8,9,10,11,12]
for i in order1:
    if i==1:
        data=dddA[(pd.to_datetime('20170'+str(i)+'31')>=dddA['支付时间']) & (dddA['支付时间']>=pd.to_datetime('20170'+str(i)+'01'))]
        print('第'+str(i)+'月的日均订单量为:',(data.shape[0])/31)
        print('第'+str(i)+'月的每单平均交易额为:',(np.sum(data['实际金额']))/data.shape[0])
    if i==2:
        data=dddA[(pd.to_datetime('20170'+str(i)+'28')>=dddA['支付时间']) & (dddA['支付时间']>=pd.to_datetime('20170'+str(i)+'01'))]
        print('第'+str(i)+'月的日均订单量为:',(data.shape[0])/28)
        print('第'+str(i)+'月的每单平均交易额为:',(np.sum(data['实际金额']))/data.shape[0])
    if i<=7 & i>=3:
       if i%2==0:
        data=dddA[(pd.to_datetime('20170'+str(i)+'30')>=dddA['支付时间']) & (dddA['支付时间']>=pd.to_datetime('20170'+str(i)+'01'))]
        print('第'+str(i)+'月的日均订单量为:',(data.shape[0])/30)
        print('第'+str(i)+'月的每单平均交易额为:',(np.sum(data['实际金额']))/data.shape[0])
       else:
        data=dddA[(pd.to_datetime('20170'+str(i)+'31')>=dddA['支付时间']) & (dddA['支付时间']>=pd.to_datetime('20170'+str(i)+'01'))]
        print('第'+str(i)+'月的日均订单量为:',(data.shape[0])/31)
        print('第'+str(i)+'月的每单平均交易额为:',(np.sum(data['实际金额']))/data.shape[0])
    if i<=9 & i>=7:
        if i%2==0: 
           data=dddA[(pd.to_datetime('20170'+str(i)+'31')>=dddA['支付时间']) & (dddA['支付时间']>=pd.to_datetime('20170'+str(i)+'01'))]
           print('第'+str(i)+'月的日均订单量为:',(data.shape[0])/31)
           print('第'+str(i)+'月的每单平均交易额为:',(np.sum(data['实际金额']))/data.shape[0])
        else:
           data=dddA[(pd.to_datetime('20170'+str(i)+'30')>=dddA['支付时间']) & (dddA['支付时间']>=pd.to_datetime('20170'+str(i)+'01'))]
           print('第'+str(i)+'月的日均订单量为:',(data.shape[0])/30)
           print('第'+str(i)+'月的每单平均交易额为:',(np.sum(data['实际金额']))/data.shape[0])
    if i>=10:
        if i%2==0: 
           data=dddA[(pd.to_datetime('2017'+str(i)+'31')>=dddA['支付时间']) & (dddA['支付时间']>=pd.to_datetime('2017'+str(i)+'01'))]
           print('第'+str(i)+'月的日均订单量为:',(data.shape[0])/31)
           print('第'+str(i)+'月的每单平均交易额为:',(np.sum(data['实际金额']))/data.shape[0])
        else:
           data=dddA[(pd.to_datetime('2017'+str(i)+'30')>=dddA['支付时间']) & (dddA['支付时间']>=pd.to_datetime('2017'+str(i)+'01'))]
           print('第'+str(i)+'月的日均订单量为:',(data.shape[0])/30)
           print('第'+str(i)+'月的每单平均交易额为:',(np.sum(data['实际金额']))/data.shape[0])
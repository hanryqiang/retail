#以8月份为例
import pandas as pd
import numpy as np
aaa = pd.read_csv(r'D:\大作业\task1-1c.csv',encoding='utf_8_sig')
aaa['支付时间'] = pd.to_datetime(aaa['支付时间'])
sss=[]
for j in range(1,32):
    month6=aaa[(aaa['支付时间'].dt.day==j) & (aaa['支付时间'].dt.month==8) ]
    ss=[] 
    for i in range(0,24):
        dd=month6[month6['支付时间'].dt.hour==i]
        cc=dd.shape[0]
        ss.append(cc)
    sss.append(ss)
import matplotlib.pyplot as plt
x = np.arange(1,31)
y = np.arange(0,24)
height = 26
width = 31
arr = np.zeros((height, width))
for i in range(len(x)):
    for j in range(len(y)):
        arr[j, i] = sss[i][j]
plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False
plt.matshow(arr, cmap='hot')
plt.colorbar()
plt.xlabel('天数')
plt.ylabel('小时数')
plt.title('8月热力图')
plt.show()
import pandas as pd
import matplotlib.pyplot as plt
#先转化为utf8，读取附件1
aaa = pd.read_csv(r'D:\大作业\附件1.csv',encoding='utf_8_sig')
aaa['支付时间'] = pd.to_datetime(aaa['支付时间'])
#提取6月份数据
month6=aaa[aaa['支付时间'].dt.month==6]
#提取销量前5数据
bbb=month6['商品'].value_counts()[:5]
# 设置中文显示
plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False
label = ['怡宝纯净水','40g双汇玉米热狗肠','东鹏特饮','脉动','250ml维他柠檬茶']# 刻度标签
plt.figure(figsize=(8,8))
plt.bar(range(5), bbb, width = 0.5)
plt.xlabel('商品')
plt.ylabel('销量')
plt.xticks(range(5), label)
plt.title('2017年6月销量前5商品销量柱状图')

for i in range(len(bbb)):
    plt.text(i, bbb[i], bbb[i], va='bottom', ha='center')

plt.show()
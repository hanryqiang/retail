import pandas as pd

bbb = pd.read_csv(r'D:\大作业\附件2.csv',encoding='gbk')

a1 = pd.read_csv(r'D:\大作业\task1-1A.csv',encoding='utf_8_sig')
a2 = pd.read_csv(r'D:\大作业\task1-1B.csv',encoding='utf_8_sig')
a3 = pd.read_csv(r'D:\大作业\task1-1C.csv',encoding='utf_8_sig')
a4 = pd.read_csv(r'D:\大作业\task1-1D.csv',encoding='utf_8_sig')
a5 = pd.read_csv(r'D:\大作业\task1-1E.csv',encoding='utf_8_sig')
outfile1 = pd.merge(a1, bbb, how='left', left_on=u'商品',right_on='商品')
outfile2 = pd.merge(a2, bbb, how='left', left_on=u'商品',right_on='商品')
outfile3 = pd.merge(a3, bbb, how='left', left_on=u'商品',right_on='商品')
outfile4 = pd.merge(a4, bbb, how='left', left_on=u'商品',right_on='商品')
outfile5 = pd.merge(a5, bbb, how='left', left_on=u'商品',right_on='商品')

outfile1.to_csv(r'D:\大作业\合并数据A.csv',index=False,encoding='utf_8_sig')
outfile2.to_csv(r'D:\大作业\合并数据B.csv',index=False,encoding='utf_8_sig')
outfile3.to_csv(r'D:\大作业\合并数据C.csv',index=False,encoding='utf_8_sig')
outfile4.to_csv(r'D:\大作业\合并数据D.csv',index=False,encoding='utf_8_sig')
outfile5.to_csv(r'D:\大作业\合并数据E.csv',index=False,encoding='utf_8_sig')